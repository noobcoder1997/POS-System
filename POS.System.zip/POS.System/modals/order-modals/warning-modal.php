<div class="modal fade" id="modal-warning" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content">
            <div class="modal-body">
                <center class="my-4">
                    <h1 class="far fa-times-circle" style="font-weight:500px;font-size:150px;color:#dc3545"></h1>
                    <h4 class="mt-4 mb-0">Can't find customer...</h4>
                </center>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" data-bs-target="#add-customer-modal" data-bs-toggle="modal">Add Customer</button>
            </div>
        </div>
    </div>
</div>